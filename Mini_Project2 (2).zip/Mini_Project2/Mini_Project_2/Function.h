/*
 * Function.h
 *
 *  Created on: Sep 16, 2022
 *      Author: Dell
 */

#ifndef FUNCTION_H_
#define FUNCTION_H_
void TIMER1_Init_CTC_Mode(void);
void Sev_seg_second(unsigned char seconds);
void Sev_seg_mins(unsigned char mins);
void Sev_seg_hours(unsigned char hrs);
void INT0_Init(void);
void INT1_Init(void);
void INT2_Init(void);




#endif /* FUNCTION_H_ */
